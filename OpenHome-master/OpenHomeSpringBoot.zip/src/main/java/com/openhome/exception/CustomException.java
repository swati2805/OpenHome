package com.openhome.exception;

public class CustomException extends Exception{

	public CustomException(String msg) {
		super(msg);
	}
	
}
